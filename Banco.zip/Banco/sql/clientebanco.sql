CREATE DATABASE IF NOT EXISTS clientebanco DEFAULT CHARACTER SET utf8;

USE clientebanco;

DROP TABLE IF EXISTS CUSTOMER;
CREATE TABLE CUSTOMER (
    ID       VARCHAR(20) NOT NULL,
    FIRSTNAME VARCHAR(50),
    LASTNAME  VARCHAR(50),
    BALANCE   DOUBLE,
    PRIMARY KEY (ID)
);

INSERT INTO CUSTOMER (ID, FIRSTNAME, LASTNAME, BALANCE) VALUES
('c1', 'Juliana', 'Lopez',     1250.50),
('c2', 'Camila',  'Rodriguez',  4770.25),
('c3', 'Santiago','Gonzalez',    980.00),
('c4', 'Daniel',  'Martinez',   3300.75);