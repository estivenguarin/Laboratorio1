package com.tdea.view;

import com.tdea.session.CustomerFacadeLocal;
import java.io.Serializable;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean(name = "bankingBeanAjax")
@SessionScoped
public class BankingBeanAjax extends BankingBeanBase implements Serializable {

    @EJB
    private CustomerFacadeLocal customerFacade;

    private String message = "";

    public BankingBeanAjax() {
    }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    @Override
    public String showBalance() {
        if (password == null || !password.equals("secret")) {
            message = "Incorrect password";
        } else {
            customer = customerFacade.findById(customerId);
            if (customer == null) {
                message = "Unknown customer";
            } else {
                message = String.format("Balance for %s %s is $%,.2f",
                        customer.getFirstname(),
                        customer.getLastname(),
                        customer.getBalance());
            }
        }
        return null;
    }
}