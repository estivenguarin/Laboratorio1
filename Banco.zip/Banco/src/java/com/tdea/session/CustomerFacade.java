package com.tdea.session;

import com.tdea.entity.Customer;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

@Stateless
public class CustomerFacade extends AbstractFacade<Customer> implements CustomerFacadeLocal {

    @PersistenceContext(unitName = "BancoAjaxPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public CustomerFacade() {
        super(Customer.class);
    }

    public Customer findById(String id) {
        try {
            Query q = em.createNamedQuery("Customer.findById");
            q.setParameter("id", id);
            return (Customer) q.getSingleResult();
        } catch (Exception e) {
            System.out.print("Excepcion : " + e);
            return null;
        }
    }
}